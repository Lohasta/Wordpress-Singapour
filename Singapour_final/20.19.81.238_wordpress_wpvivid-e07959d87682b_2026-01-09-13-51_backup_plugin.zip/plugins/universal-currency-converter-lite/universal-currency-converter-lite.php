<?php
/**
 * Plugin Name: Universal Currency Converter Lite
 * Plugin URI: https://sadf.theanalysthub.ng/partner
 * Description: Convert currencies with live rates and customizable styles via a shortcode and settings page.
 * Version: 1.1
 * Author: The Analyst Hub
 * Author URI: https://theanalysthub.ng
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: universal-currency-converter-lite
 * Domain Path: /languages
 */

// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants.
define('UNIVCUCO_LITE_VERSION', '1.1');
define('UNIVCUCO_LITE_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('UNIVCUCO_LITE_PLUGIN_URL', plugin_dir_url(__FILE__));

/**
 * Register the admin menu and settings.
 */
function univcuco_lite_settings_menu() {
    add_options_page(
        'Currency Converter Settings',
        'Currency Converter',
        'manage_options',
        'universal-currency-converter-lite',
        'univcuco_lite_settings_page'
    );
}
add_action('admin_menu', 'univcuco_lite_settings_menu');

/**
 * Register plugin settings.
 */
function univcuco_lite_register_settings() {
    register_setting('univcuco-lite-settings-group', 'univcuco_lite_converter_color', ['sanitize_callback' => 'sanitize_hex_color']);
    register_setting('univcuco-lite-settings-group', 'univcuco_lite_button_color', ['sanitize_callback' => 'sanitize_hex_color']);
    register_setting('univcuco-lite-settings-group', 'univcuco_lite_text_color', ['sanitize_callback' => 'sanitize_hex_color']);
    register_setting('univcuco-lite-settings-group', 'univcuco_lite_border_style', ['sanitize_callback' => 'sanitize_text_field']);
    register_setting('univcuco-lite-settings-group', 'univcuco_lite_default_currency', ['sanitize_callback' => 'sanitize_text_field']);
    register_setting('univcuco-lite-settings-group', 'univcuco_lite_target_currency', ['sanitize_callback' => 'sanitize_text_field']);
}
add_action('admin_init', 'univcuco_lite_register_settings');

/**
 * Admin settings page HTML.
 */
function univcuco_lite_settings_page() {
    ?>
    <div class="wrap">
        <h2><?php echo esc_html__('Currency Converter Settings', 'universal-currency-converter-lite'); ?></h2>
        <?php settings_errors(); ?>
        <form method="post" action="options.php">
            <?php settings_fields('univcuco-lite-settings-group'); ?>
            <?php do_settings_sections('univcuco-lite-settings-group'); ?>

            <table class="form-table">
                <tr valign="top">
                    <th scope="row"><?php echo esc_html__('Default Currency:', 'universal-currency-converter-lite'); ?></th>
                    <td><input type="text" name="univcuco_lite_default_currency" value="<?php echo esc_attr(get_option('univcuco_lite_default_currency', 'USD')); ?>" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row"><?php echo esc_html__('Target Currency:', 'universal-currency-converter-lite'); ?></th>
                    <td><input type="text" name="univcuco_lite_target_currency" value="<?php echo esc_attr(get_option('univcuco_lite_target_currency', 'EUR')); ?>" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row"><?php echo esc_html__('Converter Color:', 'universal-currency-converter-lite'); ?></th>
                    <td>
                        <input type="color" name="univcuco_lite_converter_color" value="<?php echo esc_attr(get_option('univcuco_lite_converter_color', '#f0f0f0')); ?>" />
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row"><?php echo esc_html__('Button Color:', 'universal-currency-converter-lite'); ?></th>
                    <td>
                        <input type="color" name="univcuco_lite_button_color" value="<?php echo esc_attr(get_option('univcuco_lite_button_color', '#0073aa')); ?>" />
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row"><?php echo esc_html__('Text Color:', 'universal-currency-converter-lite'); ?></th>
                    <td>
                        <input type="color" name="univcuco_lite_text_color" value="<?php echo esc_attr(get_option('univcuco_lite_text_color', '#000000')); ?>" />
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row"><?php echo esc_html__('Border Style:', 'universal-currency-converter-lite'); ?></th>
                    <td>
                        <select name="univcuco_lite_border_style">
                            <option value="solid" <?php selected(get_option('univcuco_lite_border_style'), 'solid'); ?>><?php echo esc_html__('Solid', 'universal-currency-converter-lite'); ?></option>
                            <option value="dashed" <?php selected(get_option('univcuco_lite_border_style'), 'dashed'); ?>><?php echo esc_html__('Dashed', 'universal-currency-converter-lite'); ?></option>
                            <option value="dotted" <?php selected(get_option('univcuco_lite_border_style'), 'dotted'); ?>><?php echo esc_html__('Dotted', 'universal-currency-converter-lite'); ?></option>
                        </select>
                    </td>
                </tr>
            </table>

            <?php submit_button(); ?>
            <p><strong><?php echo esc_html__('Donate to the Developer', 'universal-currency-converter-lite'); ?></strong></p>
            <p><?php echo esc_html__('If this plugin has been helpful, consider a small donation to support future development.', 'universal-currency-converter-lite'); ?></p>
            <p><a href="https://paystack.shop/pay/bsp1ourq2f" target="_blank" class="button button-primary">Buy Me a Coffee (via Paystack)</a></p>
        </form>
    </div>
    <?php
}

/**
 * Add a settings link to the plugins page.
 */
function univcuco_lite_add_settings_link($links) {
    $settings_url = admin_url('options-general.php?page=universal-currency-converter-lite');
    $settings_link = '<a href="' . esc_url($settings_url) . '">' . __('Settings', 'universal-currency-converter-lite') . '</a>';
    array_unshift($links, $settings_link);
    return $links;
}
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'univcuco_lite_add_settings_link');

/**
 * Enqueue scripts and styles.
 */
function univcuco_lite_enqueue_assets() {
    wp_enqueue_style(
        'univcuco-lite-style',
        plugin_dir_url(__FILE__) . 'assets/css/style.css',
        [],
        UNIVCUCO_LITE_VERSION
    );

    wp_enqueue_script(
        'univcuco-lite-converter',
        plugin_dir_url(__FILE__) . 'assets/js/converter.js',
        ['jquery'],
        UNIVCUCO_LITE_VERSION,
        true
    );
}
add_action('wp_enqueue_scripts', 'univcuco_lite_enqueue_assets');

/**
 * Register the converter shortcode.
 */
function univcuco_lite_converter_shortcode($atts) {
    ob_start();

    // Default attributes.
    $atts = shortcode_atts([
        'default' => get_option('univcuco_lite_default_currency', 'USD'),
        'to' => get_option('univcuco_lite_target_currency', 'EUR'),
        'amount' => 1,
        'decimals' => 2,
    ], $atts, 'univcuco_converter');

    // Get settings.
    $converter_color = get_option('univcuco_lite_converter_color', '#f0f0f0');
    $button_color = get_option('univcuco_lite_button_color', '#0073aa');
    $text_color = get_option('univcuco_lite_text_color', '#000000');
    $border_style = get_option('univcuco_lite_border_style', 'solid');

    // Generate unique ID for the converter.
    $converter_id = 'univcuco-lite-' . uniqid();

    // The converter HTML.
    ?>
    <div id="<?php echo esc_attr($converter_id); ?>" class="currency-converter-lite" style="background-color: <?php echo esc_attr($converter_color); ?>; border-style: <?php echo esc_attr($border_style); ?>;">
        <h2><?php echo esc_html__('Currency Converter', 'universal-currency-converter-lite'); ?></h2>
        <div class="converter-row">
            <label for="from_currency_<?php echo esc_attr($converter_id); ?>"><?php echo esc_html__('From:', 'universal-currency-converter-lite'); ?></label>
            <select id="from_currency_<?php echo esc_attr($converter_id); ?>" class="currency-select from-currency">
                <option value="<?php echo esc_attr($atts['default']); ?>"><?php echo esc_html($atts['default']); ?></option>
            </select>
        </div>
        <div class="converter-row">
            <label for="to_currency_<?php echo esc_attr($converter_id); ?>"><?php echo esc_html__('To:', 'universal-currency-converter-lite'); ?></label>
            <select id="to_currency_<?php echo esc_attr($converter_id); ?>" class="currency-select to-currency">
                <option value="<?php echo esc_attr($atts['to']); ?>"><?php echo esc_html($atts['to']); ?></option>
            </select>
        </div>
        <div class="converter-row">
            <label for="amount_<?php echo esc_attr($converter_id); ?>"><?php echo esc_html__('Amount:', 'universal-currency-converter-lite'); ?></label>
            <input type="number" id="amount_<?php echo esc_attr($converter_id); ?>" value="<?php echo esc_attr($atts['amount']); ?>" step="any" class="currency-amount" style="color: <?php echo esc_attr($text_color); ?>;" />
        </div>
        
        <button id="convert_btn_<?php echo esc_attr($converter_id); ?>" class="convert-button" style="background-color: <?php echo esc_attr($button_color); ?>; color: <?php echo esc_attr($text_color); ?>;"><?php echo esc_html__('Convert', 'universal-currency-converter-lite'); ?></button>

        <div class="converter-row">
            <label for="result_<?php echo esc_attr($converter_id); ?>"><?php echo esc_html__('Result:', 'universal-currency-converter-lite'); ?></label>
            <input type="text" id="result_<?php echo esc_attr($converter_id); ?>" class="converter-result" style="color: <?php echo esc_attr($text_color); ?>;" readonly />
        </div>
        <div class="exchange-rate-disclaimer" style="color: <?php echo esc_attr($text_color); ?>;">
             <?php echo esc_html__('Live rates from ExchangeRate-API', 'universal-currency-converter-lite'); ?>
        </div>
    </div>
    <?php

    return ob_get_clean();
}
add_shortcode('univcuco_converter', 'univcuco_lite_converter_shortcode');
?>