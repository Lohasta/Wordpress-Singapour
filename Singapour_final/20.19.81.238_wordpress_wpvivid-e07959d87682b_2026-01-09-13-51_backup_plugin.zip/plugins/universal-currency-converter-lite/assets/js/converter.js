document.addEventListener('DOMContentLoaded', () => {
    // Get all converter instances on the page.
    const converters = document.querySelectorAll('.currency-converter-lite');

    converters.forEach(converter => {
        const fromSelect = converter.querySelector('.from-currency');
        const toSelect = converter.querySelector('.to-currency');
        const amountInput = converter.querySelector('.currency-amount');
        const resultInput = converter.querySelector('.converter-result');
        const convertButton = converter.querySelector('.convert-button');

        // Check for required elements before proceeding.
        if (!fromSelect || !toSelect || !amountInput || !resultInput || !convertButton) {
            console.error('One or more converter elements not found.');
            return;
        }

        let rates = {};

        // Function to fetch currency rates.
        const fetchRates = async () => {
            const api_url = 'https://open.er-api.com/v6/latest/USD';
            try {
                const response = await fetch(api_url);
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                const data = await response.json();
                rates = data.rates;
                populateCurrencies(rates);
            } catch (error) {
                console.error('Fetching rates failed:', error);
                resultInput.value = 'Rates unavailable.';
            }
        };

        // Function to populate the currency dropdowns.
        const populateCurrencies = (rates) => {
            const currencies = Object.keys(rates).sort();
            const defaultFrom = fromSelect.value;
            const defaultTo = toSelect.value;
            
            // Clear existing options to prevent duplicates.
            fromSelect.innerHTML = '';
            toSelect.innerHTML = '';

            currencies.forEach(currency => {
                const option1 = document.createElement('option');
                option1.value = currency;
                option1.textContent = currency;
                fromSelect.appendChild(option1);

                const option2 = document.createElement('option');
                option2.value = currency;
                option2.textContent = currency;
                toSelect.appendChild(option2);
            });

            // Set the original default values from PHP.
            fromSelect.value = defaultFrom;
            toSelect.value = defaultTo;
        };

        // Function to perform the conversion.
        const convert = () => {
            if (Object.keys(rates).length === 0) {
                console.error('Rates not available.');
                return;
            }

            const fromCurrency = fromSelect.value;
            const toCurrency = toSelect.value;
            const amount = parseFloat(amountInput.value);

            if (isNaN(amount) || amount <= 0) {
                resultInput.value = ''; // Set to empty string
                return;
            }

            const rateFromUSD = rates[fromCurrency];
            const rateToUSD = rates[toCurrency];

            if (rateFromUSD && rateToUSD) {
                const convertedAmount = (amount / rateFromUSD) * rateToUSD;
                resultInput.value = convertedAmount.toFixed(2);
            } else {
                resultInput.value = 'Error';
            }
        };

        // Event listener for the button.
        convertButton.addEventListener('click', convert);

        // Event listeners to clear the result on currency changes.
        fromSelect.addEventListener('change', () => {
            resultInput.value = '';
        });
        toSelect.addEventListener('change', () => {
            resultInput.value = '';
        });
        
        // Initialize the script by fetching rates.
        fetchRates();
    });
});