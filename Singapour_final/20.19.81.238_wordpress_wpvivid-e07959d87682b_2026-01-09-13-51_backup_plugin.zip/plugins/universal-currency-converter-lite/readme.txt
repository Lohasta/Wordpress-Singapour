=== Universal Currency Converter Lite ===
Contributors: ebiboweinabena
Donate link: https://paystack.shop/pay/bsp1ourq2f
Tags: currency, converter, finance, shortcode, donations
Requires at least: 5.8
Requires PHP: 7.4
Tested up to: 6.8
Stable tag: 1.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A lightweight currency converter with shortcode support, live exchange rates, customizable colors, and a settings page.

== Description ==

Universal Currency Converter Lite lets you add a simple currency converter to any page or post using a shortcode. It fetches live exchange rates, allows you to set default and target currencies, and style the widget (background, button, text colors) from an admin settings page.

**Features**

* Live rates from ExchangeRate-API (relative to USD).
* Shortcode to embed anywhere.
* Admin page to choose default & target currencies.
* Color pickers for background, button, and text colors.
* Optional “Buy Me a Coffee” link inside the settings page (Paystack).

**Shortcode**

Use:
`[univcuco_converter]`

Override defaults per instance:
`[univcuco_converter default="EUR" to="GBP" amount="10" decimals="2"]`

== Installation ==

1. Upload the plugin folder to `/wp-content/plugins/universal-currency-converter-lite` or install the ZIP via **Plugins → Add New → Upload Plugin**.
2. Activate the plugin.
3. Configure options under **Settings → Currency Converter** (optional).
4. Add the shortcode `[univcuco_converter]` to any page, post, or widget.

== Screenshots ==

1. Screenshot of the currency converter on a post.
2. Screenshot of the admin settings page.
3. Screenshot showing the color options.

== Frequently Asked Questions ==

= How do I change the default currencies? =

Go to **Settings → Currency Converter**. You can also override per shortcode with `default` and `to`.

= Can I change colors? =

Yes. Use the background, button, and text color pickers in the settings page.

= Where is the donation link? =

Inside the settings page only. It does not appear in the plugin list row.

== Upgrade Notice ==

= 1.1 =

* New: A header "Currency Converter" is now displayed above the converter.
* New: The result box now automatically clears when a currency selection is changed.
* New: The "Convert" button is now fully functional and is the sole trigger for conversion.
* Fix: The result box is now positioned below the button for improved user experience.
* Fix: Frontend assets (CSS & JS) now correctly load on all pages with the shortcode.
* New: Added a "Settings" link to the plugin list page for easy access.

== External Services ==

This plugin connects to an external service to fetch live currency exchange rates.

* **Service Used**: ExchangeRate-API (https://open.er-api.com/)
* **Purpose**: To retrieve up-to-date currency exchange rates for the converter.
* **Data Sent**: The base currency code (e.g., USD, EUR) in each request. No personal or identifiable user data is sent.
* **Data Received**: Exchange rates for multiple currencies, displayed in the converter widget/shortcode.
* **Privacy & Terms**:
  - Terms of Service: https://www.exchangerate-api.com/terms
  - Privacy Policy: https://www.exchangerate-api.com/privacy

This connection is required for the plugin to function. If the API is unavailable, live exchange rates will not be displayed.

== Changelog ==

= 1.1 =
* **New:** A header "Currency Converter" is now displayed above the converter.
* **New:** The result box now automatically clears when a currency selection is changed.
* **Fix:** The "Convert" button is now fully functional and is the sole trigger for conversion.
* **Fix:** The result box is now positioned below the button for improved user experience.
* **Fix:** Frontend assets (CSS & JS) now correctly load on all pages with the shortcode.
* **New:** Added a "Settings" link to the plugin list page for easy access.

= 1.0 =
* Initial release: shortcode widget, settings page, color controls, safe escaping, and JSON output hardening.

== Roadmap ==

We’re actively improving **Currency Converter**. Here’s what’s coming:

### Current (v1.1)
- Frontend assets now correctly load.
- Added "Settings" link to plugins list page.
- "Convert" button is now the sole trigger.
- Result box is now below the button.
- Header added to converter widget.
- Result box clears on currency changes.

### Next Update (v1.2)
- API fallback support for more reliable rates.
- Option to show currency symbols (e.g., $ for USD, ₦ for NGN).
- Friendlier error handling if rates are unavailable.

### Planned (v1.3)
- Auto-detect user currency (browser/IP).
- Control over decimal places (0–4).
- New styling options (rounded fields, light/dark mode).

### Future (v2.0 and beyond)
- Convert into multiple currencies at once.
- Historical rates (7-day/30-day view).
- Offline caching of last rates.
- WooCommerce integration (optional).
- Gutenberg block support.

Have a feature request? Open a thread in the [support forum](https://wordpress.org/support/plugin/universal-currency-converter-lite/).