<?php
//Begin Really Simple Security session cookie settings
@ini_set('session.cookie_httponly', true);
@ini_set('session.cookie_secure', true);
@ini_set('session.use_only_cookies', true);
//END Really Simple Security cookie settings
//Begin Really Simple Security key
//define('RSSSL_KEY', 'XBUp80kKa1BJY3gOyjAuD9949VuQk49C26SuylUg4g8rU2TMJAODb6qMtRp3JRXH');
//END Really Simple Security key

/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the website, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://developer.wordpress.org/advanced-administration/wordpress/wp-config/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wp431a976' );

/** Database username */
define( 'DB_USER', 'wpuser976a431' );

/** Database password */
define( 'DB_PASSWORD', 'lgxiiicrucial22' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

@ini_set( 'upload_max_size' , '20M' );
@ini_set( 'post_max_size', '13M');
@ini_set( 'memory_limit', '15M' );
/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'ubq+BvqZbw|W1snayx)adbq (I?]_k;n|99G_,rXnhZo`!YwH:]q21BYmxiG@eJ1' );
define( 'SECURE_AUTH_KEY',  'End=4]sqY Watb0=_68_*<MykU<NL:McK5X0U4:&VTX97%^_PK|$-7Qk+5Cx1z,k' );
define( 'LOGGED_IN_KEY',    'e~?(fEq%#b^Ilc6?,|W/oql,]~>i|AeptB]20BYyr?`B7u?9L;i^H$`0MLP3,$j$' );
define( 'NONCE_KEY',        '${:5]l8Hkd9~9V!Slf^wbhNqx5tY@C.K4$ctTj!.|~it0^>~!=)Svd,(i.}Qr`j}' );
define( 'AUTH_SALT',        ')jXlxW7dM* .%wZ|u};2KQNQChjw^>yR?|R$>hii-~$Vx9@z0gGipEpa6+Q0;x)[' );
define( 'SECURE_AUTH_SALT', '{a=^|w{ue6M#w(j k@9,e_mJnUfydT Sm~4}eDh}kfWZ@FS8I73+t+3bz5~[RSqr' );
define( 'LOGGED_IN_SALT',   '%`JzNfUKx-125%]}Z1eVI<p9CD,L5GZ~*;%Z_E$xKUn5cB;oC=xbMS %Vw)v.:Z`' );
define( 'NONCE_SALT',       'q281d5NMcK7Fcag=8|0VojqGS]+Lmea xhlrh[y}l0nw5.O1Xi#*P~_iHWz,_iD*' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 *
 * At the installation time, database tables are created with the specified prefix.
 * Changing this value after WordPress is installed will make your site think
 * it has not been installed.
 *
 * @link https://developer.wordpress.org/advanced-administration/wordpress/wp-config/#table-prefix
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://developer.wordpress.org/advanced-administration/debug/debug-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';


define('FS_METHOD', 'direct');

define('WP_HOME','http://20.19.81.238/wordpress');
define('WP_SITEURL','http://20.19.81.238/wordpress');
define( 'WP_CACHE', false );
define('FORCE_SSL_ADMIN', false);
